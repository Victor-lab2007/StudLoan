const rateLimit = require('express-rate-limit');

// Login: 5 attempts per 15 min per IP
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many login attempts. Please try again in 15 minutes.' },
});

// Security-question verification (forgot password step): stricter,
// since this is the path an attacker would brute-force instead of the password.
const securityQuestionLimiter = rateLimit({
  windowMs: 30 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many attempts. Please try again in 30 minutes.' },
});

// Password reset completion, once questions are verified
const resetLimiter = rateLimit({
  windowMs: 30 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
});

module.exports = { loginLimiter, securityQuestionLimiter, resetLimiter };
