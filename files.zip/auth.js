const express = require('express');
const jwt = require('jsonwebtoken');
const pool = require('../db/pool');
const { hash, verify, normalizeAnswer } = require('../utils/password');
const {
  loginLimiter,
  securityQuestionLimiter,
  resetLimiter,
} = require('../middleware/rateLimiter');

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET; // must be set in env, never hardcoded

function signToken(user) {
  return jwt.sign(
    { userId: user.id, role: user.role },
    JWT_SECRET,
    { expiresIn: '1h' }
  );
}

async function logAudit(client, { userId, action, details, ip }) {
  await client.query(
    `INSERT INTO audit_logs (user_id, action, details, ip_address, created_at)
     VALUES ($1, $2, $3, $4, now())`,
    [userId, action, details ? JSON.stringify(details) : null, ip]
  );
}

// ---------- LOGIN ----------
router.post('/login', loginLimiter, async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  const client = await pool.connect();
  try {
    const { rows } = await client.query(
      'SELECT id, email, password_hash, role, security_questions_set FROM users WHERE email = $1',
      [email]
    );
    const user = rows[0];

    // Same generic error whether the email doesn't exist or the password is
    // wrong, so attackers can't use this endpoint to enumerate accounts.
    if (!user || !(await verify(password, user.password_hash))) {
      await logAudit(client, { userId: user?.id ?? null, action: 'login_failed', ip: req.ip });
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    await logAudit(client, { userId: user.id, action: 'login_success', ip: req.ip });

    const token = signToken(user);
    return res.json({
      token,
      mustSetSecurityQuestions: !user.security_questions_set,
    });
  } finally {
    client.release();
  }
});

// ---------- LIST AVAILABLE SECURITY QUESTIONS ----------
router.get('/security-questions/bank', async (_req, res) => {
  const { rows } = await pool.query(
    'SELECT id, question_text FROM security_question_bank WHERE active = TRUE ORDER BY id'
  );
  res.json(rows);
});

// ---------- FIRST-TIME SETUP: user picks & answers exactly 3 ----------
// body: { userId, answers: [{ questionId, answer }, x3] }
router.post('/security-questions/setup', async (req, res) => {
  const { userId, answers } = req.body;

  if (!Array.isArray(answers) || answers.length !== 3) {
    return res.status(400).json({ error: 'Exactly 3 security questions are required.' });
  }
  const questionIds = answers.map((a) => a.questionId);
  if (new Set(questionIds).size !== 3) {
    return res.status(400).json({ error: 'Please choose 3 different questions.' });
  }
  if (answers.some((a) => !a.answer || a.answer.trim().length < 2)) {
    return res.status(400).json({ error: 'Every answer must be at least 2 characters.' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Wipe any partial prior attempt so re-running setup doesn't violate the
    // "max 3" trigger or leave stale questions behind.
    await client.query('DELETE FROM user_security_questions WHERE user_id = $1', [userId]);

    for (const { questionId, answer } of answers) {
      const answerHash = await hash(normalizeAnswer(answer));
      await client.query(
        `INSERT INTO user_security_questions (user_id, question_id, answer_hash)
         VALUES ($1, $2, $3)`,
        [userId, questionId, answerHash]
      );
    }

    await client.query('UPDATE users SET security_questions_set = TRUE WHERE id = $1', [userId]);
    await logAudit(client, { userId, action: 'security_questions_set', ip: req.ip });

    await client.query('COMMIT');
    res.json({ success: true });
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
});

// ---------- FORGOT PASSWORD: step 1 — fetch this user's 3 questions ----------
router.post('/forgot-password/questions', async (req, res) => {
  const { email } = req.body;
  const { rows } = await pool.query(
    `SELECT u.id AS user_id, b.id AS question_id, b.question_text
     FROM users u
     JOIN user_security_questions usq ON usq.user_id = u.id
     JOIN security_question_bank b ON b.id = usq.question_id
     WHERE u.email = $1`,
    [email]
  );

  // Deliberately vague response if the email doesn't exist or has no
  // questions set, so this can't be used to enumerate valid accounts.
  if (rows.length !== 3) {
    return res.status(200).json({
      message: 'If this account exists and has security questions set up, they will be shown.',
      questions: [],
    });
  }

  res.json({
    userId: rows[0].user_id,
    questions: rows.map((r) => ({ questionId: r.question_id, questionText: r.question_text })),
  });
});

// ---------- FORGOT PASSWORD: step 2 — verify answers, issue reset token ----------
router.post('/forgot-password/verify', securityQuestionLimiter, async (req, res) => {
  const { userId, answers } = req.body; // [{ questionId, answer }, x3]

  if (!Array.isArray(answers) || answers.length !== 3) {
    return res.status(400).json({ error: 'All 3 answers are required.' });
  }

  const client = await pool.connect();
  try {
    const { rows } = await client.query(
      'SELECT question_id, answer_hash FROM user_security_questions WHERE user_id = $1',
      [userId]
    );

    let allCorrect = rows.length === 3;
    for (const { questionId, answer } of answers) {
      const record = rows.find((r) => r.question_id === questionId);
      const ok = record && (await verify(normalizeAnswer(answer), record.answer_hash));
      if (!ok) allCorrect = false;
    }

    await client.query(
      `INSERT INTO security_question_attempts (user_id, succeeded, ip_address)
       VALUES ($1, $2, $3)`,
      [userId, allCorrect, req.ip]
    );

    if (!allCorrect) {
      return res.status(401).json({ error: 'One or more answers were incorrect.' });
    }

    // Short-lived, single-purpose token — only good for setting a new password
    const resetToken = jwt.sign({ userId, purpose: 'password_reset' }, JWT_SECRET, {
      expiresIn: '15m',
    });
    await logAudit(client, { userId, action: 'security_questions_verified', ip: req.ip });

    res.json({ resetToken });
  } finally {
    client.release();
  }
});

// ---------- FORGOT PASSWORD: step 3 — set new password ----------
router.post('/forgot-password/reset', resetLimiter, async (req, res) => {
  const { resetToken, newPassword } = req.body;

  let payload;
  try {
    payload = jwt.verify(resetToken, JWT_SECRET);
  } catch {
    return res.status(401).json({ error: 'Reset link is invalid or has expired.' });
  }
  if (payload.purpose !== 'password_reset') {
    return res.status(401).json({ error: 'Invalid reset token.' });
  }
  if (!newPassword || newPassword.length < 10) {
    return res.status(400).json({ error: 'Password must be at least 10 characters.' });
  }

  const client = await pool.connect();
  try {
    const newHash = await hash(newPassword);
    await client.query('UPDATE users SET password_hash = $1 WHERE id = $2', [
      newHash,
      payload.userId,
    ]);
    await logAudit(client, { userId: payload.userId, action: 'password_reset_via_security_questions', ip: req.ip });
    res.json({ success: true });
  } finally {
    client.release();
  }
});

module.exports = router;
