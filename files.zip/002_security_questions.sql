-- Migration: security questions for account recovery
-- Run after your existing 001_init.sql (users, admin_profiles, etc.)

BEGIN;

-- Flag on users so the app knows to force setup on first login
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS security_questions_set BOOLEAN NOT NULL DEFAULT FALSE;

-- A fixed bank of allowed questions (keeps answers predictable/hashable,
-- and stops users typing trivially-guessable custom questions)
CREATE TABLE IF NOT EXISTS security_question_bank (
  id            SERIAL PRIMARY KEY,
  question_text TEXT NOT NULL UNIQUE,
  active        BOOLEAN NOT NULL DEFAULT TRUE
);

INSERT INTO security_question_bank (question_text) VALUES
  ('What was the name of your first school?'),
  ('What is your mother''s maiden name?'),
  ('What was the name of your first pet?'),
  ('What city were you born in?'),
  ('What is the name of your best friend from high school?'),
  ('What was the make of your first car?'),
  ('What is your favorite childhood nickname?'),
  ('What is the name of the street you grew up on?')
ON CONFLICT (question_text) DO NOTHING;

-- Each user picks exactly 3 questions and answers them; answers are hashed,
-- never stored in plaintext, exactly like the password column.
CREATE TABLE IF NOT EXISTS user_security_questions (
  id              SERIAL PRIMARY KEY,
  user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  question_id     INTEGER NOT NULL REFERENCES security_question_bank(id),
  answer_hash     TEXT NOT NULL,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, question_id)
);

-- Enforce exactly 3 questions per user at the DB level via a trigger,
-- so nothing can bypass the app layer and store fewer/more.
CREATE OR REPLACE FUNCTION enforce_three_security_questions()
RETURNS TRIGGER AS $$
DECLARE
  q_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO q_count FROM user_security_questions WHERE user_id = NEW.user_id;
  IF q_count > 3 THEN
    RAISE EXCEPTION 'A user may have at most 3 security questions';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_max_three_security_questions ON user_security_questions;
CREATE TRIGGER trg_max_three_security_questions
  AFTER INSERT ON user_security_questions
  FOR EACH ROW EXECUTE FUNCTION enforce_three_security_questions();

-- Track failed security-question attempts for lockout / rate limiting
CREATE TABLE IF NOT EXISTS security_question_attempts (
  id          SERIAL PRIMARY KEY,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  succeeded   BOOLEAN NOT NULL,
  ip_address  INET,
  attempted_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_sqa_user_time ON security_question_attempts (user_id, attempted_at);

COMMIT;
