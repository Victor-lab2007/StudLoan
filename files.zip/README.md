# StudLoan Auth Module — Admin Reset + First-Login Security Questions

I couldn't reach `github.com/Victor-lab2007/StudLoan` directly (it's private or not
yet pushed to, from this environment), so these are drop-in files rather than a
PR against your actual repo. Copy this folder's contents into your Express
project, matching the existing `db/`, `routes/`, `middleware/`, `utils/` layout.

## 1. Install dependencies
```bash
npm install bcrypt dotenv express express-rate-limit jsonwebtoken pg
```

## 2. Apply the migration
Run `db/002_security_questions.sql` against your Postgres database (after your
existing schema). It adds:
- `security_questions_set` flag on `users`
- `security_question_bank` (fixed list of 8 questions to choose from)
- `user_security_questions` (each user's 3 chosen questions + hashed answers)
- `security_question_attempts` (for lockout/audit)

## 3. Reset the admin account you're locked out of
Set env vars and run the script once:
```bash
ADMIN_EMAIL=you@studloan.co.za ADMIN_PASSWORD='a-strong-new-passphrase' \
DATABASE_URL=postgres://user:pass@host:5432/studloan \
npm run reset-admin
```
This deletes the existing `role = 'admin'` row(s) and creates a fresh admin
with a bcrypt-hashed password. Nothing is printed or logged in plaintext.

## 4. Mount the auth routes
In your main server file:
```js
const authRoutes = require('./routes/auth');
app.use('/api/auth', authRoutes);
```
Also set `JWT_SECRET` in your `.env` (a long random string) — never hardcode it.

## 5. Frontend flow to wire up
- **Login** (`POST /api/auth/login`) returns `mustSetSecurityQuestions: true`
  the first time. If true, redirect to a "set up 3 security questions" screen
  before letting the user reach their dashboard.
- **Setup** (`POST /api/auth/security-questions/setup`) — fetch the question
  bank from `GET /api/auth/security-questions/bank`, let the user pick 3 and
  answer them.
- **Forgot password**:
  1. `POST /api/auth/forgot-password/questions` with `{ email }` → returns
     that user's 3 stored questions (never the bank at large, and never
     reveals whether the email exists).
  2. `POST /api/auth/forgot-password/verify` with all 3 answers → returns a
     short-lived `resetToken` if correct.
  3. `POST /api/auth/forgot-password/reset` with `{ resetToken, newPassword }`
     → sets the new password.

## Security notes baked in
- Passwords and security-question answers are both bcrypt-hashed (12 rounds) —
  answers are never stored in plaintext.
- Answers are normalized (trimmed + lowercased) before hashing, so casing
  doesn't cause false negatives.
- Rate limiting on login (5/15min), security-question verification
  (5/30min), and reset completion — the question-verification path is
  limited harder since it's the most attractive brute-force target.
- Every login, security-question setup, verification, and admin reset is
  written to `audit_logs`.
- A DB trigger hard-enforces "exactly 3 questions" so the limit can't be
  bypassed by a bug in the app layer.
- Login and "forgot password" responses are deliberately generic so neither
  endpoint can be used to enumerate valid emails.
