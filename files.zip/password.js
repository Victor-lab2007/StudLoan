const bcrypt = require('bcrypt');

const SALT_ROUNDS = 12;

/**
 * Hash a plaintext value (password OR security-question answer).
 * Answers are normalized first (trim + lowercase) so "Blue" and "blue "
 * both verify correctly later.
 */
async function hash(plainText) {
  return bcrypt.hash(plainText, SALT_ROUNDS);
}

async function verify(plainText, hashed) {
  return bcrypt.compare(plainText, hashed);
}

function normalizeAnswer(answer) {
  return answer.trim().toLowerCase();
}

module.exports = { hash, verify, normalizeAnswer };
