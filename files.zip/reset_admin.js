/**
 * Run once to replace the admin account you're locked out of.
 *
 * Usage:
 *   ADMIN_EMAIL=new-admin@studloan.co.za \
 *   ADMIN_PASSWORD='choose-a-strong-passphrase' \
 *   DATABASE_URL=postgres://... \
 *   node scripts/reset_admin.js
 *
 * This does NOT print or store the password anywhere — you supply it via
 * env var at run time and it's hashed immediately.
 */
require('dotenv').config();
const pool = require('../db/pool');
const { hash } = require('../utils/password');

async function main() {
  const email = process.env.ADMIN_EMAIL;
  const password = process.env.ADMIN_PASSWORD;

  if (!email || !password) {
    console.error('Set ADMIN_EMAIL and ADMIN_PASSWORD env vars before running this script.');
    process.exit(1);
  }
  if (password.length < 12) {
    console.error('Choose an admin password of at least 12 characters.');
    process.exit(1);
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Remove every existing admin-role account you've been locked out of.
    // (Adjust the WHERE clause if you only want to remove a specific one by id/email.)
    const deleted = await client.query(
      `DELETE FROM users WHERE role = 'admin' RETURNING id, email`
    );
    console.log(`Removed ${deleted.rowCount} old admin record(s):`, deleted.rows);

    const passwordHash = await hash(password);
    const inserted = await client.query(
      `INSERT INTO users (email, password_hash, role, security_questions_set, created_at)
       VALUES ($1, $2, 'admin', FALSE, now())
       RETURNING id, email, role`,
      [email, passwordHash]
    );
    console.log('Created new admin:', inserted.rows[0]);

    await client.query(
      `INSERT INTO audit_logs (user_id, action, details, created_at)
       VALUES ($1, 'admin_credentials_reset', $2, now())`,
      [inserted.rows[0].id, JSON.stringify({ note: 'admin reset via reset_admin.js script' })]
    );

    await client.query('COMMIT');
    console.log('\nDone. Log in with the new email/password, then set up your 3 security questions when prompted.');
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Failed, rolled back:', err.message);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

main();
